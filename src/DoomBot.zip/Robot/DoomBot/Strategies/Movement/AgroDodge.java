package Robot.DoomBot.Strategies.Movement;

import Generic.Classes.ContextData;
import Generic.Interfaces.IMovementState;
import robocode.AdvancedRobot;
import robocode.ScannedRobotEvent;

public class AgroDodge implements IMovementState
{
	double previousEnergy = 100;
	int movementDirection = 1;
	int gunDirection = 1;
	int tics = 0;
	int ticLimit = 100;

	@Override
	public void Handle(AdvancedRobot pRobot) 
	{
		pRobot.setTurnGunRight(99999);
		
	}

	@Override
	public void onScannedRobotEvent(ScannedRobotEvent pEvent, AdvancedRobot pRobot) 
	{
		tics ++;
		// Stay at right angles to the opponent
		pRobot.setTurnRight(pEvent.getBearing()+90-30*movementDirection);
		 // If the bot has small energy drop,assume it fired
	    double changeInEnergy = previousEnergy-pEvent.getEnergy();
	    
	    if (changeInEnergy>0 && changeInEnergy<=3 || tics >=  ticLimit) 
	    {
	            // Dodge!
	             movementDirection = -movementDirection;
	             pRobot.setAhead((pEvent.getDistance()/4+25)*movementDirection);
	             //reset tic
	             tics = 0;
	    }
	        // When a bot is spotted,
	        // sweep the gun and radar
	        //gunDirection = -gunDirection;
	    	//pRobot.setTurnGunRight(99999*gunDirection);
	        
	        // Fire directly at target
	        pRobot.fire ( ContextData.getInstance().getFirePower() ) ;
	        
	        // Track the energy level
	        previousEnergy = pEvent.getEnergy();
	}
	


}
