package Robot.DoomBot.Strategies.GatherInfo;

import Generic.Interfaces.IGatherInfoState;
import robocode.AdvancedRobot;
import robocode.ScannedRobotEvent;

public class FullScan implements IGatherInfoState 
{

	@Override
	public void Handle(AdvancedRobot pRobot) 
	{
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onScannedRobotEvent(ScannedRobotEvent pEvent, AdvancedRobot pRobot) 
	{
		// TODO Auto-generated method stub
		
	}

}
