package Robot.DoomBot.Strategies.GatherInfo;

import Generic.Interfaces.IGatherInfoState;
import robocode.AdvancedRobot;
import robocode.ScannedRobotEvent;

public class CircularScan implements IGatherInfoState 
{




	@Override
	public void Handle(AdvancedRobot pRobot) 
	{
		pRobot.turnRadarRight(360);	
		
	}

	@Override
	public void onScannedRobotEvent(ScannedRobotEvent pEvent, AdvancedRobot pRobot) 
	{
		
		
	}
	
	
	

}


