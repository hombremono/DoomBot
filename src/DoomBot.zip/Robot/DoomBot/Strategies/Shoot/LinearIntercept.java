package Robot.DoomBot.Strategies.Shoot;

import Generic.Classes.ContextData;
import Generic.Classes.Intercept;
import Generic.Classes.MathHelper;
import Generic.Interfaces.IShootingState;
import robocode.AdvancedRobot;
import robocode.ScannedRobotEvent;

public class LinearIntercept implements IShootingState
{

	@Override
	public void Handle(AdvancedRobot pRobot) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onScannedRobotEvent(ScannedRobotEvent pEvent, AdvancedRobot pRobot) 
	{
		 Intercept intercept = new Intercept();

	        intercept.calculate
	                (
	                		pRobot.getX(),
	                		pRobot.getY(),
	                		pRobot.getX() + Math.sin(Math.toRadians(pRobot.getHeading() + pEvent.getBearing())) * pEvent.getDistance(),
	                		pRobot.getY() + Math.cos(Math.toRadians(pRobot.getHeading() + pEvent.getBearing())) * pEvent.getDistance(),
	                		pEvent.getHeading(),
	                		pEvent.getVelocity(),
	                		ContextData.getInstance().getFirePower(),
	                        0 // Angular velocity
	                );

	        double turnAngle = MathHelper.normalizeBearing
	                (intercept.bulletHeading_deg - pRobot.getGunHeading());
	        pRobot.setTurnGunRight(turnAngle);

	        if (Math.abs(turnAngle) <= intercept.angleThreshold) {
	            // Ensure that the gun is pointing at the correct angle
	            if (
	                    (intercept.impactPoint.x > 0) &&
	                            (intercept.impactPoint.x < pRobot.getBattleFieldWidth()) &&
	                            (intercept.impactPoint.y > 0) &&
	                            (intercept.impactPoint.y < pRobot.getBattleFieldHeight())
	                    ) {
	                // Ensure that the predicted impact point is within
	                // the battlefield
	            	pRobot.fire(intercept.bulletPower);
	            }
	        }
		
	}

}
