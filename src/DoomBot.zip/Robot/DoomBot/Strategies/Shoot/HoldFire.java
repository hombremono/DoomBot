package Robot.DoomBot.Strategies.Shoot;

import Generic.Classes.ContextData;
import Generic.Classes.Enemy;
import Generic.Interfaces.IShootingState;
import robocode.AdvancedRobot;
import robocode.ScannedRobotEvent;

public class HoldFire implements IShootingState
{

	@Override
	public void Handle(AdvancedRobot pRobot) 
	{
		//Enemy e = ContextData.getInstance().getTarget();
		

	}

	@Override
	public void onScannedRobotEvent(ScannedRobotEvent pEvent, AdvancedRobot pRobot) 
	{
		double absoluteBearing = pRobot.getHeadingRadians() + pEvent.getBearingRadians();
		pRobot.setTurnGunRightRadians(robocode.util.Utils.normalRelativeAngle(absoluteBearing - pRobot.getGunHeadingRadians()));
		pRobot.fire(ContextData.getInstance().getFirePower());
		
	}

}
