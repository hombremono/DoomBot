package Robot.DoomBot;
import Generic.Classes.ContextData;
import Generic.Classes.Intercept;
import Generic.Interfaces.IStrategy;
import Generic.Strategies.TestStrategy;
import robocode.AdvancedRobot;
import robocode.Robot;
import robocode.Rules;
import robocode.ScannedRobotEvent;
import robocode.util.Utils;



public class DoomBot extends AdvancedRobot
{
	//IShootingState pShootingState,IMovementState pMovementState ,IGatherInfoState pGaterInfoState
	//private static DoomBot instance = null;
	IStrategy oStrategy;

	   
	
	
	public void run() 
	{
		//ContextData.getInstance().setMovementStrategy("Dodge");
		oStrategy = new TestStrategy();
		setAdjustGunForRobotTurn(true);
		this.setAdjustRadarForGunTurn(true);
		ContextData.getInstance().setFirePower(1.5f);
		
		while (true) 
		{
			oStrategy.PlanStrategy(this);
			oStrategy.ExecuteStrategy(this);
		}
	}  
	float firepower = 1.5f;
	

	@Override
	public void onScannedRobot(ScannedRobotEvent e)
	{
		//ContextData.getInstance()e.set
		oStrategy.onScannedRobotStrategy(this, e);
		ContextData.getInstance().addOrUpdateEnemy(e, this);
		

	}
	
	private double limit(double value, double min, double max) {
	    return Math.min(max, Math.max(min, value));
	}

}


