package Generic.Interfaces;

import robocode.AdvancedRobot;
import robocode.Robot;
import robocode.ScannedRobotEvent;

public interface IGatherInfoState 
{
	void Handle(AdvancedRobot pRobot);
	void onScannedRobotEvent(ScannedRobotEvent pEvent,AdvancedRobot pRobot);
}
