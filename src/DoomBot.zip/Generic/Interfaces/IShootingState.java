package Generic.Interfaces;

import robocode.AdvancedRobot;
import robocode.ScannedRobotEvent;

public interface IShootingState 
{
	void Handle(AdvancedRobot pRobot);
	void onScannedRobotEvent(ScannedRobotEvent pEvent,AdvancedRobot pRobot);
}
