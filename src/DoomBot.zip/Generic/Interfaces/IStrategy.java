package Generic.Interfaces;

import Generic.Classes.ContextData;
import robocode.AdvancedRobot;
import robocode.ScannedRobotEvent;

public interface IStrategy 
{
	
	public void PlanStrategy(AdvancedRobot pRobot);
	public void ExecuteStrategy(AdvancedRobot pRobot);
	public void onScannedRobotStrategy(AdvancedRobot pRobot,ScannedRobotEvent pEvent);
}
