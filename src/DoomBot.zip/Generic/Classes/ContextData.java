package Generic.Classes;

import java.util.ArrayList;
import java.util.List;


import robocode.AdvancedRobot;
import robocode.ScannedRobotEvent;



public class ContextData 
{
	private static ContextData instance = null;
	private List<Enemy>  lstDetectedRobots;
	public Enemy oTarget;
	private String MovementStrategy;
	
	private double firePower=0.1f;
	//private ScannedRobotEvent Target;
	
	
	
	public String getMovementStrategy() {
		return MovementStrategy;
	}

	public void setMovementStrategy(String movementStrategy) {
		MovementStrategy = movementStrategy;
	}

	protected ContextData ()
	{
		lstDetectedRobots = new ArrayList<Enemy>();
	}
	
	public double getFirePower() {
		return firePower;
	}

	public void setFirePower(double firePower) 
	{
		this.firePower = firePower;
	}

	public static ContextData getInstance() {
	      if(instance == null) 
	      {
	         instance = new ContextData();
	      }
	      return instance;
	   }
	
	

	public Enemy getTarget() {
		return oTarget;
	}

	public void setTarget(Enemy oTarget) 
	{
		this.oTarget = oTarget;
	}

	public List<Enemy> getLstDetectedRobots() 
	{
		return lstDetectedRobots;
	}

	public void addDetectedRobot(Enemy pDetectedRobot) 
	{
		if(!lstDetectedRobots.contains(pDetectedRobot))
		{
			lstDetectedRobots.add(pDetectedRobot);
		}
	}
	public void addOrUpdateEnemy (ScannedRobotEvent pEvent, AdvancedRobot pRobot)
	{
		
	        int temp = isUniqueRobot(pEvent);
	        if(temp == -1)
	        {
	        	lstDetectedRobots.add(new Enemy(pEvent, pRobot));
	        	//System.out.println(pEvent.getName() + " agregado");

	        }
	        else
	        {
	        	lstDetectedRobots.get(temp).update(pEvent, pRobot); 
	        	//System.out.println(pEvent.getName() + " actualizado");
	        }

	}
	
	public Enemy getClosestEnemy()
    {
        double distance = Double.MAX_VALUE;
        Enemy closestEnemy = null;
        for (Enemy e : lstDetectedRobots){
            if (e.distance < distance){
                closestEnemy = e;
                distance = closestEnemy.distance;
            }
        }
        return closestEnemy;
    }
	
	private int isUniqueRobot(ScannedRobotEvent e)
	{
        if (lstDetectedRobots.isEmpty())
            return -1; 
        for (int i = 0; i < lstDetectedRobots.size(); i++)
            if (lstDetectedRobots.get(i).name.equals(e.getName()))
                return i;
        return -1;

    }
	

}

