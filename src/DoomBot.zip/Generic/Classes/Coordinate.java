package Generic.Classes;


	public class Coordinate {
	    public double x, y;
	    public Coordinate(double x, double y){
	        this.x = x;
	        this.y = y;
	    }

	    public Coordinate(){

	    }

	    public void set(double x, double y){
	        this.x = x;
	        this.y = y;
	    }
	}


