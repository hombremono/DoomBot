package Generic.Strategies;

import Generic.Classes.BasicContext;
import Generic.Classes.ContextData;
import Generic.Interfaces.IContext;
import Generic.Interfaces.IStrategy;
import Robot.DoomBot.Strategies.GatherInfo.*;
import Robot.DoomBot.Strategies.Movement.*;
import Robot.DoomBot.Strategies.Shoot.*;
import robocode.AdvancedRobot;
import robocode.ScannedRobotEvent;

public class TestStrategy implements IStrategy
{
	
	private IContext oContext;
	
	
	public TestStrategy ()
	{
		 oContext = new BasicContext(new AngularIntercept(),new AgroDodge(),new WidthLock());
		 //ContextData.getInstance().setMovementStrategy("Dodge");
	}

	@Override
	public void PlanStrategy(AdvancedRobot pRobot) 
	{
		/*System.out.println(pRobot.getEnergy());
		if(pRobot.getEnergy() < 30 && ContextData.getInstance().getMovementStrategy() != "Agro")
		{
			oContext.setMovementState(new AgroDodge());
			System.out.println("agro");
			ContextData.getInstance().setMovementStrategy("Agro");
		}
		else if(ContextData.getInstance().getMovementStrategy() == "Agro")
		{
			oContext.setMovementState(new SideDodge());
			System.out.println("dodge");
			ContextData.getInstance().setMovementStrategy("Dodge");
		}*/

			
	}

	@Override
	public void ExecuteStrategy(AdvancedRobot pRobot) 
	{
		oContext.GatherInformationAction(pRobot);
		oContext.MovementStateAction(pRobot);
		oContext.ShootingStateAction(pRobot);
		
	}

	@Override
	public void onScannedRobotStrategy(AdvancedRobot pRobot, ScannedRobotEvent pEvent) 
	{
		ContextData Data = ContextData.getInstance();
		double firePower = Math.min(500 / pEvent.getDistance(), 3);
		Data.setFirePower(firePower);

		//System.out.println(Data.getFirePower());
		oContext.getGatherInfoState().onScannedRobotEvent(pEvent, pRobot);
		oContext.getShootingState().onScannedRobotEvent(pEvent, pRobot);
		oContext.getMovementState().onScannedRobotEvent(pEvent, pRobot);
	}

}
